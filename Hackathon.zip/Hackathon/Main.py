import streamlit as st

st.set_page_config(page_title="BioScout Islamabad", page_icon="🌿", layout="wide")

st.title("🌿 BioScout Islamabad")
st.markdown("""
Welcome to **BioScout Islamabad**, a community-powered biodiversity monitoring platform.

🚶 Submit observations  
🔍 Explore wildlife data  
🧠 Ask AI about local biodiversity  
""")

st.page_link("pages/Submit_Observation.py", label="📸 Submit an Observation")
st.page_link("pages/Explore_Observations.py", label="🗺️ Explore Observations")
st.page_link("pages/Ask_AI.py", label="🤖 Ask AI")

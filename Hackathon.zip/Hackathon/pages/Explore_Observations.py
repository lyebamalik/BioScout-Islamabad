import streamlit as st
import pandas as pd
import os

st.title("🗺️ Explore Community Observations")

# CSV ka path
csv_path = "data/observations.csv"

# Agar file exist nahi karti
if not os.path.exists(csv_path):
    st.warning("No observations yet. Submit one first.")
else:
    df = pd.read_csv(csv_path)
    df.columns = ['observer', 'species_name', 'date_observed', 'location', 'notes', 'image_filename', 'original_species']
    print(df.columns)
    print(df.shape)

    # DataFrame dikhayo
    st.dataframe(df)

    with st.expander("🎖️ Top Observers"):
        if not df.empty:
            if 'observer' in df.columns:
                # Top 3 observers
                observer_counts = df['observer'].value_counts().head(3)

                for i, (observer, count) in enumerate(observer_counts.items()):
                    if i == 0:
                        st.write(f"🥇 {observer} — {count} submissions")
                    elif i == 1:
                        st.write(f"🥈 {observer} — {count} submissions")
                    elif i == 2:
                        st.write(f"🥉 {observer} — {count} submissions")

                if len(observer_counts) < 3:
                    st.info(f"Only {len(observer_counts)} observers so far!")
            else:
                st.error("⚠️ 'observer' column not found in the data.")
        else:
            st.write("No observations yet to determine top observers.")

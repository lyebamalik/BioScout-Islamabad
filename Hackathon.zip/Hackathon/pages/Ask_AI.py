import streamlit as st
import pandas as pd
from pathlib import Path
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import re
from difflib import get_close_matches
import os

# API Configuration
OPENAI_API_KEY = ""
OPIK_API_KEY = ""
OPIK_WORKSPACE = ""

# OpenAI and OPIK Setup
from openai import OpenAI
from opik.integrations.openai import track_openai

# ✅ FIXED: Correct usage of track_openai with 2 arguments
openai_client = track_openai(
    OpenAI(api_key=OPENAI_API_KEY),
    {
        "api_key": OPIK_API_KEY,
        "workspace": OPIK_WORKSPACE
    }
)

# Streamlit Config
st.set_page_config(page_title="Islamabad Wildlife Assistant", layout="wide")

# Constants
KNOWLEDGE_DIR = "data/knowledge_base"
OBSERVATIONS_FILE = "data/observations.csv"
MODEL_NAME = "all-MiniLM-L6-v2"
SPECIES_TAXONOMY = ["leopard", "monkey", "bird", "snake", "butterfly", "pigeon"]

# Load embedding model
@st.cache_resource
def load_embedding_model():
    return SentenceTransformer(MODEL_NAME)

model = load_embedding_model()

def clean_species_name(name):
    if not isinstance(name, str):
        return ""
    return re.sub(r'[^a-zA-Z ]', '', name).strip().lower().title()

def correct_spelling(text, possible_words):
    if not text or not possible_words:
        return text
    closest = get_close_matches(text.lower(), possible_words, n=1, cutoff=0.6)
    return closest[0].title() if closest else text

def load_and_correct_observations():
    if not os.path.exists(OBSERVATIONS_FILE):
        return pd.DataFrame()
    
    try:
        df = pd.read_csv(OBSERVATIONS_FILE)
        species_col = next((col for col in df.columns if 'species' in col.lower()), None)
        if species_col is None:
            return pd.DataFrame()
        
        df['original_species'] = df[species_col].copy()
        df[species_col] = df[species_col].apply(
            lambda x: correct_spelling(clean_species_name(x), SPECIES_TAXONOMY)
        )
        return df
    except Exception as e:
        st.error(f"Error loading observations: {str(e)}")
        return pd.DataFrame()

def load_knowledge():
    knowledge = []
    for file in Path(KNOWLEDGE_DIR).glob("*.txt"):
        try:
            content = file.read_text(encoding='utf-8')
            species = file.stem.replace('_', ' ').title()
            knowledge.append({
                "content": content,
                "source": "Official Knowledge",
                "species": species,
                "type": "knowledge",
                "embedding": model.encode(content)
            })
        except Exception as e:
            st.warning(f"Skipped {file.name}: {str(e)}")
    return knowledge

def load_observations():
    observations = []
    df = load_and_correct_observations()
    if df.empty:
        return observations
    
    species_col = next((col for col in df.columns if 'species' in col.lower()), 'species')
    
    for _, row in df.iterrows():
        if pd.isna(row[species_col]):
            continue
            
        text = f"Species: {row[species_col]}\n"
        if 'original_species' in row and row['original_species'] != row[species_col]:
            text += f"(Originally: {row['original_species']})\n"
        
        for field in ['location', 'date', 'notes']:
            col = next((c for c in df.columns if field in c.lower()), None)
            if col and col in row and pd.notna(row[col]):
                text += f"{col.title()}: {row[col]}\n"
        
        observations.append({
            "content": text,
            "source": "Community Observation",
            "species": row[species_col],
            "type": "observation",
            "embedding": model.encode(text)
        })
    
    return observations

def enhanced_search(query, data):
    if not data:
        return []

    clean_query = clean_species_name(query)
    corrected_query = correct_spelling(clean_query, SPECIES_TAXONOMY)
    query_embed = model.encode(query.lower())
    doc_embeds = np.array([d['embedding'] for d in data])
    sims = cosine_similarity(query_embed.reshape(1, -1), doc_embeds)[0]

    results = []
    for i, score in enumerate(sims):
        result = data[i].copy()
        result['score'] = float(score)

        if result['species'].lower() in query.lower():
            result['score'] = min(1.0, result['score'] + 0.5)
        elif result['species'].lower() == corrected_query.lower():
            result['score'] = min(1.0, result['score'] + 0.3)

        if result['score'] > 0.25:
            results.append(result)

    results.sort(key=lambda x: (x['type'] != 'knowledge', -x['score']))
    return results[:3]

def show_page():
    st.title("🌿 Islamabad Wildlife Assistant")
    
    if "messages" not in st.session_state:
        st.session_state.messages = []

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    if prompt := st.chat_input("Ask about local biodiversity..."):
        st.session_state.messages.append({"role": "user", "content": prompt})
        
        with st.chat_message("user"):
            st.markdown(prompt)
        
        with st.chat_message("assistant"):
            with st.spinner("Analyzing data..."):
                try:
                    knowledge = load_knowledge()
                    observations = load_observations()
                    all_data = knowledge + observations

                    results = enhanced_search(prompt, all_data)

                    if not results:
                        response = "No relevant information found. Try different species names."
                    else:
                        context = "\n\n".join([
                            f"Source: {r['source']}\nSpecies: {r['species']}\n{r['content']}"
                            for r in results
                        ])

                        completion = openai_client.chat.completions.create(
                            model="gpt-3.5-turbo",
                            messages=[{
                                "role": "user",
                                "content": f"""Answer based on this context:
                                {context}

                                Question: {prompt}
                                - Be concise (1-3 sentences)
                                - Mention source types used
                                - Never invent information"""
                            }]
                        )
                        response = completion.choices[0].message.content

                except Exception as e:
                    response = f"⚠️ Error: {str(e)}"

                st.markdown(response)
                st.session_state.messages.append({"role": "assistant", "content": response})

if __name__ == "__main__":
    show_page()

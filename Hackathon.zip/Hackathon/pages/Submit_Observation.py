import streamlit as st
import pandas as pd
import requests
import os
from datetime import date

st.title("📸 Submit a Biodiversity Observation")

# Input fields
observer_name = st.text_input("Observer Name")
species_name = st.text_input("Species Name (common or scientific)")
observation_date = st.date_input("Date Observed", date.today())
location = st.text_input("Location (e.g., Margalla Hills)")
image = st.file_uploader("Upload Image (optional)", type=["jpg", "jpeg", "png"])
notes = st.text_area("Additional Notes (habitat, behavior, etc.)")

def query_inaturalist_api(query):
    try:
        url = "https://api.inaturalist.org/v1/taxa"
        params = {"q": query}
        response = requests.get(url, params=params)
        data = response.json()
        if data["results"]:
            result = data["results"][0]
            suggestion = {
                "scientific_name": result["name"],
                "common_name": result.get("preferred_common_name", "Not available"),
                "image_url": result.get("default_photo", {}).get("medium_url", ""),
                "rank": result["rank"]
            }
            return suggestion
    except Exception as e:
        st.warning(f"API error: {e}")
    return None

# Show AI suggestion based on species name input
if species_name:
    suggestion = query_inaturalist_api(species_name)
    if suggestion:
        st.markdown("🔍 **AI-Powered Suggestion (from iNaturalist):**")
        st.write(f"**Common Name:** {suggestion['common_name']}")
        st.write(f"**Scientific Name:** *{suggestion['scientific_name']}*")
        st.write(f"**Rank:** {suggestion['rank']}")
        if suggestion["image_url"]:
            st.image(suggestion["image_url"], caption="Suggested Species")

if st.button("Submit Observation"):
    data = {
        "observer": observer_name,  # ✅ ADD THIS LINE
        "species_name": species_name,
        "date_observed": observation_date.strftime("%Y-%m-%d"),
        "location": location,
        "notes": notes,
        "image_filename": image.name if image else "None"
    }

    df = pd.DataFrame([data])
    os.makedirs("data", exist_ok=True)
    csv_path = "data/observations.csv"

    if os.path.exists(csv_path):
        df.to_csv(csv_path, mode='a', header=False, index=False)
    else:
        df.to_csv(csv_path, index=False)

    st.success("✅ Observation submitted!")
